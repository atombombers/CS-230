package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */

//Team class extends Entity, inheriting its properties and methods
public class Team extends Entity {
	
	// Static list to store players
	private static List<Player> players = new ArrayList<Player>();
	
	// Constructor to initialize a Team with a unique id and name
	public Team(long id, String name) {
		this.id = id; // Inherits 'id' from Entity
		this.name = name; // Inherits 'name' from Entity
	}
	
	// Method to add a player to the team if they don't already exist
	public Player addPlayer(String name) {
		
		Player tempPlayer = null;

		// Loops through the existing players to check for duplicates
		for (Player currPlayer : players) {
			if (currPlayer.name.equalsIgnoreCase(name)){
				// Returns the existing player if found
				return currPlayer; 
			}			
		}
		
		// Gets the GameService singleton instance
		GameService tempService = GameService.getGameService();
		
		// Creates a new player with a unique ID and the provided name
		tempPlayer = new Player(tempService.getNextPlayerId(), name);
		
		// Adds the new player to the players list	
		players.add(tempPlayer);
		
		// Returns the newly added player
		return tempPlayer;
	}
	
	//Overriding the toString method to provide a custom string representation of the Team object
	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}