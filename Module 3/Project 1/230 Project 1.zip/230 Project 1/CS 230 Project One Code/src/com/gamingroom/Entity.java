package com.gamingroom;

//A base class to hold player, team, and game attributes
public class Entity {
	
	// Protected attributes to store the id and name of the entity so subclasses can inherit
	protected long id;
	protected String name;
	
	// Protected class constructor so subclasses can call
	protected Entity() {}
	
	// Public constructor to initialize Entity objects with id and name
	public Entity(long id, String name) {
		this.id = id;
		this.name = name;
	}

	// Public getter method to retrieve the id of the entity
	public long getId() {
		return id;
	}
	
	// Public getter method to retrieve the name of the entity
	public String getName() {
		return name;
	}
	
	// Overriding the toString method to provide a custom string representation of the Entity object
	@Override
	public String toString() {
		return "Entity [id=" + id + ", name=" + name + "]";
	}	
	
}
