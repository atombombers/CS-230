package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */

//Game class extends Entity, inheriting id and name fields
public class Game extends Entity {
	
	// Static list of teams, shared across all Game instances
	private static List<Team> teams = new ArrayList<Team>();

	// Private constructor to prevent instantiation
	@SuppressWarnings("unused")
	private Game() {}

	// Public constructor to initialize a Game with a unique id and name
	public Game(long id, String name) {
		this.id = id; // Inherits 'id' from Entity
		this.name = name; // Inherits 'name' from Entity
	}
	
	// Method to add a team to the game if it doesn't already exist
	public Team addTeam(String name) {
		
		Team tempTeam = null;
		
		// Loops through the list of teams to check if a team with the given name already exists
		for (Team currTeam : teams) {
			if (currTeam.name.equalsIgnoreCase(name)){ // Compares team names to avoid duplicates
				return currTeam; // Return the existing team if found
			}			
		}

		// Retrieves the GameService instance
		GameService tempService = GameService.getGameService();
		
		// Creates a new team with a unique ID and the given name
		tempTeam = new Team(tempService.getNextTeamId(), name);
		
		// Adds the newly created team to the list of teams
		teams.add(tempTeam);
		
		// Returns the newly added team
		return tempTeam;
		
	}
	
	// Overriding the toString method to provide a custom string representation of the Game object
	@Override
	public String toString() {
		return "Game [id=" + id + ", name=" + name + "]";
	}

}