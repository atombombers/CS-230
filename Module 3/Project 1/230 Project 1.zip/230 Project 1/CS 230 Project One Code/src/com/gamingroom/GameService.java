package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */

public class GameService {
	
	// List to store all the games
	private static List<Game> games = new ArrayList<Game>();
	
	// Unique IDs for games, players, and teams that increment when used
	private static long nextGameId = 1;
	private static long nextPlayerId = 1;
	private static long nextTeamId = 1;
	
	// Singleton instance of GameService
	private static GameService service = null;
	
	// Private constructor to prevent instantiation from outside the class
	private GameService() {}
	
    /**
     * Provides access to the single instance of GameService.
     * Implements the Singleton pattern — only one instance of GameService is created.
     * @return The singleton instance of GameService
     */
	
	public static GameService getGameService() {
		if (service == null) {
			service = new GameService();
		}

		return service;
	}

    /**
     * Adds a new game to the list if it doesn't already exist.
     * @param name The name of the game to add.
     * @return The newly added game, or the existing game if one with the same name already exists.
     */
	
	public Game addGame(String name) {
		
		// a local game instance
		Game game = null;
		
		// Check if a game with the same name already exists
		if (getGame(name) != null) {
			game = getGame(name);
		}
		 // Create a new game and add it to the list
		else {
			game = new Game(nextGameId++, name);
			games.add(game);
		}
		return game;
	}


	Game getGame(int index) {
		return games.get(index);
	}
	
    /**
     * Retrieves a game by its unique ID.
     * @param id The ID of the game.
     * @return The game with the specified ID, or null if not found.
     */
	
	public Game getGame(long id) {
		
		// a local game instance
		Game game = null;
		
		// Loop through all games and find the one with the matching ID
		for (Game currGame:games) {
			if (currGame.getId() == id) {
				game = currGame;
				break;
			}
		}		

		return game;
	}

	
    /**
     * Retrieves a game by its name (case-insensitive).
     * @param name The name of the game.
     * @return The game with the specified name, or null if not found.
     */
	
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// Loop through all games and find the one with the matching name
		for (Game currGame:games) {
			if(currGame.getName().equalsIgnoreCase(name)) {
				game = currGame;
				break;
			}
		}
		return game;
	}

    /**
     * Gets the total number of games.
     * @return The number of games in the list.
     */
	
	public int getGameCount() {
		return games.size();
	}
	
    /**
     * Generates and returns the next unique player ID.
     * @return The next player ID.
     */
	
	public long getNextPlayerId() {
		return nextPlayerId++;
	}
	
    /**
     * Generates and returns the next unique team ID.
     * @return The next team ID.
     */
	
	public long getNextTeamId() {
		return nextTeamId++;
	}
	
}
